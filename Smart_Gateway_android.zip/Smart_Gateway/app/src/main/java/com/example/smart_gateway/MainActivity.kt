package com.example.smart_gateway

import android.os.Bundle
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.smart_gateway.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Configure WebView settings
        binding.webView.settings.javaScriptEnabled = true
        binding.webView.settings.userAgentString = "SmartHomeGatewayApp/1.0"
        
        binding.webView.webViewClient = object : WebViewClient() {
            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                super.onReceivedError(view, request, error)
                Toast.makeText(
                    this@MainActivity,
                    "Load failed: ${error?.description ?: "Unknown error"}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        binding.connectButton.setOnClickListener {
            val ip = binding.ipEditText.text.toString().trim()
            
            // Simple validation check for IP address
            if (ip.isBlank() || !android.util.Patterns.IP_ADDRESS.matcher(ip).matches()) {
                Toast.makeText(this@MainActivity, "Invalid IP Address", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            // Append "/advance" to the URL using cleartext HTTP
            val url = "http://$ip/advance"
            
            // Load the generated URL
            binding.webView.loadUrl(url)
        }
    }
}
